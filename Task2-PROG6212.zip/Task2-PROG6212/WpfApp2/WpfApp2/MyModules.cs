﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    class MyModules
    {
        public string moduleCode { get; set; }
        public string moduleName { get; set; }
        public string credits { get; set; }
        public string weeklyHours { get; set; }
        public string semesterWeeks { get; set; }
        public string startDate { get; set; }
        public string selfstudy { get; set; }
        public string hoursremaining { get; set; }
        public string recorddate { get; set; }
    }
}
